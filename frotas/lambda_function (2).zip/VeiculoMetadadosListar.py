import CFIotTwinMaker

def Testar():

    cEntity = CFIotTwinMaker.CEntity()

    workSpace = cEntity.Listar(workspaceId='VehicleFleetWorkspace1')


Testar()  
print('testou')  